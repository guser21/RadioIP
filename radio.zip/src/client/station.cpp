#include <client/station.h>

Station InvalidStation("INVALID_STATION", "INVALID_ADDR", 1, 1);

