//
// Created by guser on 5/28/18.
//

#ifndef RADIO_UI_CLIENT_H
#define RADIO_UI_CLIENT_H
class UIClient{
public:
    int socket;
    int last_sent_byte;
};
#endif //RADIO_UI_CLIENT_H
